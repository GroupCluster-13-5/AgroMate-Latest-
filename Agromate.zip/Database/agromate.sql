-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2023 at 05:50 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `agromate`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_submissions`
--

CREATE TABLE `contact_submissions` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_submissions`
--

INSERT INTO `contact_submissions` (`id`, `name`, `email`, `message`, `submission_date`) VALUES
(8, 'jms construction', 'jmsconslanka@gmail.com', 'gfhgfhfghdhdh', '2023-08-03 06:25:12'),
(10, 'jms construction', 'jmsconslanka@gmail.com', 'gfhgfhfghdhdh', '2023-08-03 08:07:51'),
(19, 'Pathirage Tineth Vihanga', 'tinethpathirage@gmail.com', 'hellow', '2023-12-03 15:26:11');

-- --------------------------------------------------------

--
-- Table structure for table `diseases`
--

CREATE TABLE `diseases` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `control_methods` text DEFAULT NULL,
  `symptoms` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diseases`
--

INSERT INTO `diseases` (`id`, `name`, `description`, `control_methods`, `symptoms`, `image`) VALUES
(2, 'Cephaleuros virescens', 'Life cycle\r\nThe alga produces microscopic, rust-colored, spore-like\r\nbodies on the surface of the leaf spots, giving them a\r\nreddish tinge. The “spores” are dispersed by wind or rain.\r\nThe alga may spread from leaves to branches and fruit.\r\nPoor soil drainage, imbalanced nutrition, and exposure\r\nto relatively high temperature and humidity predispose\r\ntea plants to infection by algal leaf spot, so it is important\r\nto strengthen the plant through proper cultivation and fertilization. Most algal spots develop on the upper leaf surface. Older infections become greenish-gray and look like\r\nlichen. Cephaleuros usually does not harm the plant.', 'Avoid plant stress. Avoid poorly drained sites. Promote\r\ngood air circulation in the plant canopy to reduce humidity and duration of leaf wetness.', 'Leaves develop lesions that are roughly circular, raised,\r\nand purple to reddish-brown.\r\n', 'uploads/cephaleuros-virescens.jpg'),
(3, 'Brown blight, grey blight', 'These fungi are considered weak pathogens and usually\r\nonly affect plants that have been weakened by improper\r\ncare or adverse environmental conditions. The disease\r\nis favored by poor air circulation, high temperature, and\r\nhigh humidity or prolonged periods of leaf wetness.\r\nWhen young twigs of susceptible cultivars are cut and\r\nused to root new plants, latent mycelium in the leaf tissue may start to invade nearby cells to form brown spots,\r\nand this may lead to death of leaves and twigs', 'None are known.', 'Small, oval, pale yellow-green spots first appear on\r\nyoung leaves. Often the spots are surrounded by a narrow, yellow zone. As the spots grow and turn brown or\r\ngray, concentric rings with scattered, tiny black dots become visible and eventually the dried tissue falls, leading to defoliation. Leaves of any age can be affected.\r\n', 'uploads/download.jpeg'),
(4, 'Blister blight', 'Blister blight is the most serious disease affecting shoots\r\nof tea and is capable of causing enormous crop loss. The\r\ndisease is endemic to most tea-growing areas of Asia but\r\nis not known to occur in Africa or the Americas. Cloudy,\r\nwet weather favors infection. Shan or Indian varieties of\r\ntea are somewhat resistant to this disease.\r\nLife cycle\r\nThe disease cycle repeats continuously during favorable\r\n(wet) conditions, and the spores are readily dispersed\r\nby wind. Spores that land on a leaf with adequate moisture will germinate and infect it, producing visible symptoms within 10 days. The fungus can directly penetrate\r\nthe leaf tissue. The basidiospores have a low survival\r\nrate under conditions of drought or bright sunlight. The\r\nlife cycle of the fungus is 3–4 weeks.', 'None; the only known host is Camellia sinensis', 'Small, pinhole-size spots are initially seen on young\r\nleaves less than a month old. As the leaves develop, the\r\nspots become transparent, larger, and light brown. After\r\nabout 7 days, the lower leaf surface develops blister-like\r\nsymptoms, with dark green, water-soaked zones surrounding the blisters. Following release of the fungal\r\nspores, the blister becomes white and velvety. Subsequently the blister turns brown,', 'uploads/brown_blight_3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(14, 'admin', 'admin@gmail.com', '$2y$10$UCYyIX95QIRP1GIJ.m5Mse3.3wiN2GMlC/nT8t36mXgJl3nknripa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_submissions`
--
ALTER TABLE `contact_submissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `diseases`
--
ALTER TABLE `diseases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_submissions`
--
ALTER TABLE `contact_submissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `diseases`
--
ALTER TABLE `diseases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
